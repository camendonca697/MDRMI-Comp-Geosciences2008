clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
load tt.dat -ascii
load tx.dat -ascii
load ty.dat -ascii
load tz.dat -ascii
load gz.dat -ascii
load gzx.dat -ascii
load gzy.dat -ascii
load gzz.dat -ascii
load pp.dat -ascii
%
load agz.dat -ascii
load at.dat -ascii
load fdmr.dat -ascii
load fnic.dat -ascii


xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
np=length(pp(:,1));
[nx,ny]=size(tt);
%

%--------------------------------
figure
pcolor(yy,xx,gz);title('gz (mGal)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')

figure
pcolor(yy,xx,tt);title('Tt (nT)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')

figure
pcolor(yy,xx,agz);title('grad Gz (mGal/km)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')

figure
pcolor(yy,xx,at);title('T (nT)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-');
%
%
% analise da correlacao
jN=5;
V=plotaprf06(nx,ny,agz,at,jN);
CR=V(1:nx,1:ny);
SS=V(nx+1:2*nx,1:ny);   % significancia estatistica

figure
pcolor(yy,xx,CR);title('Correlation')
caxis([-1 1])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-');

%--------------------------------
%
% RMD
figure
rmdV=pp(1,7)/pp(1,11);
ch=[' r=' num2str(rmdV)];
pcolor(yy,xx,fdmr+SS);title(['RMD (mA.m2/kg) ' ch])
caxis([0 3])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%
% Inc
figure
incV=pp(1,8);
ch=[' I=' num2str(incV) ' D=' num2str(pp(1,11))];
pcolor(yy,xx,fnic+SS);title(['INC (grau) ' ch])
caxis([-90 90])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')

plotaprf00(xx,fdmr,fnic,floor(ny/2),np,pp,at,agz);
plotaprf04(xx,fdmr,fnic,floor(ny/2),np,pp,at,agz);
plotaprf05(xx,fdmr,fnic,floor(ny/2),np,pp,at,agz);
%plotaprf01(xx,Rmd,floor(ny/2),np,pp);
%plotaprf02(xx,Rnc,floor(ny/2),np,pp);




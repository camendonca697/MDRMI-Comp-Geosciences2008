clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
load tt.dat -ascii
load tx.dat -ascii
load ty.dat -ascii
load tz.dat -ascii
load gz.dat -ascii
load gzx.dat -ascii
load gzy.dat -ascii
load gzz.dat -ascii
load pp.dat -ascii
%
load agz.dat -ascii
load at.dat -ascii
load fdmr.dat -ascii
load fnic.dat -ascii


xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
np=length(pp(:,1));
[nx,ny]=size(tt);
%
%-------------------------------- CORRELATION ANALYSIS
%
%
jN=5;
cR=0.70;
sG=0.05;
V=plotaprf06(nx,ny,agz,at,jN,cR,sG);
CR=V(1:nx,1:ny);
SS=V(nx+1:2*nx,1:ny);   % significancia estatistica

figure
pcolor(yy,xx,CR);title('Correlation')
caxis([-1 1])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-');

%--------------------------------
%
% RMD
figure
rmdV=pp(1,7)/pp(1,11);
ch=[' r=' num2str(rmdV) ' cR>=' num2str(cR) ' sG<=' num2str(sG)];
pcolor(yy,xx,fdmr+SS);title(['RMD (mA.m2/kg) ' ch])
caxis([0 3])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%
% Inc
figure
incV=pp(1,8);
ch=[' I=' num2str(incV) ' D=' num2str(pp(1,11))];
pcolor(yy,xx,fnic+SS);title(['INC (grau) ' ch])
caxis([-90 90])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%
%
ic=floor(ny/2);
figure
subplot(311)
tn=max(at(:,ic));
gn=max(agz(:,ic));
h=plot(xx,agz(:,ic)/gn,'-sk',xx,at(:,ic)/tn,'-sr');
legend(['TT x' num2str(tn)],['GG x' num2str(gn)]);
set(h,'markersize',2);

subplot(312)
h=stairs(xx,fdmr(:,ic),'-sk');set(h,'markersize',2);
hold on
h=plot(xx,0*SS(:,ic),'ob');set(h,'markersize',3);
for i=1:np
    rd=pp(i,7)/pp(i,11);
    plot([xi xf],[rd rd],'-r')
end
ylabel('RMD (mA.m2/kg)')
hold off

subplot(313)
h=stairs(xx,fnic(:,ic),'-sk');set(h,'markersize',2);
hold on
h=plot(xx,0*SS(:,ic),'ob');set(h,'markersize',3);
for i=1:np
    rd=pp(i,8);
    plot([xi xf],[rd rd],'-r')
end
hold off
ylabel('IM (grau)')
xlabel('Distancia (km)')



function V=plotaprf06(nx,ny,GG,TT,jN,cR,sG);
%
% cR = menor correlacao aceitavel
% sG = Signficancia estatatistica da correlacao (menor valor)
% If PP is small, say less than 0.05, then the correlation R(i,j) is significant. 
jj=2*jN+1;
j2=jj*jj;
jix=jN+1;jfx=nx-jN-1;
jiy=jN+1;jfy=ny-jN-1;
cr=zeros(nx,ny)+NaN;
pp=cr;
mSk=cr;
for ix=jix:jfx
    kix=ix-jN;
    kfx=ix+jN;
    for iy=jiy:jfy
        kiy=iy-jN;
        kfy=iy+jN;
        g=reshape(GG(kix:kfx,kiy:kfy),j2,1);
        t=reshape(TT(kix:kfx,kiy:kfy),j2,1);
        [CR PP]=corrcoef(g,t);
        cr(ix,iy)=CR(2,1);
        if PP(2,1)<=sG;
            if abs(CR(2,1))>=cR
            pp(ix,iy)=PP(2,1);
            mSk(ix,iy)=0;
        end
        end
    end
end
V=[cr; mSk];
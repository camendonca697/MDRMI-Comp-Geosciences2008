
dkm=D(:,1)*110; % conversao grau to km
ndk=length(dkm);
xi=min(dkm);xf=max(dkm);
Tt=D(:,3)/10;
hh=input('Altura de continuacao (em km, negativo para cima (-0.5)  ');
iplot=1;
V=mdrmi_all(dkm,iplot,D(:,2),Tt,-90,hh,hh);

figure;
subplot(211)
h=plot(dkm,Tt,'-sk');
set(h,'markersize',2)
ylabel('Tt (nT)')
subplot(212)
h=plot(dkm,D(:,2),'-sk');
set(h,'markersize',2)
ylabel('Gz (mGal)')
%
%
figure;
tn=max(V(:,4));
gn=max(V(:,3));
subplot(211)
h=plot(dkm,V(:,4)/tn,'-sk',dkm,V(:,3)/gn,'-sr');
legend(['TT x' num2str(tn)],['GG x' num2str(gn)]);
set(h,'markersize',2)
ylabel('Intensity Fields')
axis([xi xf 0 1])
jN=7;
ji=jN+1;
jf=ndk-jN;
cr=zeros(ndk,1)+NaN;
pp=cr;mSk=cr;
for i=ji:jf
    ki=i-jN;
    kf=i+jN;
    [CR PP]=corrcoef(V(ki:kf,3),V(ki:kf,4));
    cr(i)=CR(2,1);
    if PP(2,1)<=0.05;pp(i)=PP(2,1);mSk(i)=0;end
end
subplot(212)
h=plot(dkm,cr,'-k',dkm,pp*0,'sr');
legend('Corr degree','StaSig (p<=0.05)')
axis([xi xf -1 1]);grid on
set(h,'markersize',3)
ylabel('Corr Coef')
legend('Corr degree','Stat Signf')
% If PP is small, say less than 0.05, then the correlation R(i,j) is significant. 
%
%
figure;
subplot(211)
h=stairs(dkm,V(:,1),'-sk');
vm=mean(V(:,1));
set(h,'markersize',2)
ylabel('MDR')
axis([xi xf 0 6*vm])
title('MDR-MI')
subplot(212)
ips=NaN+zeros(ndk,1);ing=ips;
for i=1:ndk;if V(i,2)>0;ips(i,1)=V(i,2);elseif V(i,2)<0;ing(i)=V(i,2);end;end
h=stairs(dkm,V(:,2),'-sk');set(h,'markersize',2);hold on;
h=stairs(dkm,ips,'-sr');set(h,'markersize',2);
h=stairs(dkm,ing,'-sb');set(h,'markersize',2);hold off
axis([xi xf min(V(:,2)) max(V(:,2))]);ylabel('MI')
%h=plot(dkm,sign(ips),'-sr',dkm,sign(ing),'-sk');axis([xi xf -2 2]);ylabel('Polarity')
grid on
%
%
%
figure;
subplot(211)
h=stairs(dkm,V(:,1),'-sk');set(h,'markersize',3);hold on;
h=stairs(dkm,[mSk+V(:,1)],'-sg');set(h,'markersize',3);hold off
vm=mean(V(:,1));
set(h,'markersize',2)
ylabel('MDR')
axis([xi xf 0 6*vm])
title('MDR-MI')
subplot(212)
ips=NaN+zeros(ndk,1);ing=ips;
for i=1:ndk;if V(i,2)>0;ips(i,1)=V(i,2);elseif V(i,2)<0;ing(i)=V(i,2);end;end
h=stairs(dkm,V(:,2),'-sk');set(h,'markersize',2);hold on;
h=stairs(dkm,ips,'-sr');set(h,'markersize',2);
h=stairs(dkm,ing,'-sb');set(h,'markersize',2);
h=stairs(dkm,[mSk+V(:,2)],'-sg');set(h,'markersize',3);hold off
axis([xi xf min(V(:,2)) max(V(:,2))]);ylabel('MI')
%h=plot(dkm,sign(ips),'-sr',dkm,sign(ing),'-sk');axis([xi xf -2 2]);ylabel('Polarity')
grid on
%
%
%
figure
h=plot(V(:,3)*14.993,V(:,4),'sk');
set(h,'markersize',3)
xlabel('Grad Gz (mGal/km)*14.993')
ylabel('T (nT)')
axis square
grid on


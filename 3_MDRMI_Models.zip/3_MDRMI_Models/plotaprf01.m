function v=plotaprf01(x,M,ic,np,pp)
figure
xi=min(x);
xf=max(x);
subplot(211)
h=plot(x,M(:,ic),'-sk');
set(h,'markersize',3);
hold on
for i=1:np
    rd=pp(i,7)/pp(i,11);
    plot([xi xf],[rd rd],'-r')
end
hold off
v=1;
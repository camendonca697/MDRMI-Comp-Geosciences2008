GG=agz;
TT=at;

jj=2*jN+1;
j2=jj*jj;
jix=jN+1;jfx=nx-jN-1;
jiy=jN+1;jfy=ny-jN-1;
cr=zeros(nx,ny)+NaN;
pp=cr;
mSk=cr;
for ix=jix:jfx
    kix=ix-jN;
    kfx=ix+jN;
    for iy=jiy:jfy
        kiy=iy-jN;
        kfy=iy+jN;
        g=reshape(GG(kix:kfx,kiy:kfy),j2,1);
        t=reshape(TT(kix:kfx,kiy:kfy),j2,1);
        [CR PP]=corrcoef(g,t);
        cr(ix,iy)=CR(2,1);
        if PP(2,1)<=0.05;
            if CR(2,1)<=0.7
            pp(ix,iy)=PP(2,1);
            mSk(ix,iy)=0;
        end
        end
    end
end
V=[cr; mSk];
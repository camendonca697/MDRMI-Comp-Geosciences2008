function v=plotaprf05(x,Mr,Mi,ic,np,pp,AT,AG);
v1=max(max(AT(:,:)));
v2=max(max(AG(:,:)))*14.993;
vf=max(v1,v2);
figure
h=plot(AG(:,:)*14.993,AT(:,:),'sk');
%axis([0 vf 0 vf])
set(h,'markersize',2)
xlabel('(mGal/km)*14.993')
ylabel('(nT)')
axis square
grid on
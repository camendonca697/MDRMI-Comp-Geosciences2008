function v=plotaprf00(x,Mr,Mi,ic,np,pp,AT,AG);


figure
h=plot(AG(:,ic)*14.993,AT(:,ic),'sk');
set(h,'markersize',3)
xlabel('(mGal/km)*14.993')
ylabel('(nT)')
axis square
grid on
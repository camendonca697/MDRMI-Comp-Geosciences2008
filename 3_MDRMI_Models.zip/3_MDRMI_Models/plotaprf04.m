function v=plotaprf04(x,Mr,Mi,ic,np,pp,AT,AG);
figure
xi=min(x);
xf=max(x);

subplot(212)
h=plot(x,Mi(:,ic),'-sk');
set(h,'markersize',3);
hold on
for i=1:np
    rd=pp(i,8);
    plot([xi xf],[rd rd],'-r')
end
hold off
ylabel('IM (grau)')
xlabel('Distancia (km)')
subplot(211)
h=plot(x,Mr(:,ic),'-sk');
set(h,'markersize',3);
hold on
for i=1:np
    rd=pp(i,7)/pp(i,11);
    plot([xi xf],[rd rd],'-r')
end
ylabel('RMD (mA.m2/kg)')
hold off




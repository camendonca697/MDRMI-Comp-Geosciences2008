clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
load tt.dat -ascii
load tx.dat -ascii
load ty.dat -ascii
load tz.dat -ascii
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
np=length(pp(:,1));
ah=sqrt(tz.*tz+ty.*ty+tx.*tx);
AG=57.2958*acos(tz./ah);
%
%
%----------------------------MAG
figure
subplot(221)
pcolor(yy,xx,tt);title('Anom (nT)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
subplot(222)
pcolor(yy,xx,AG);title('Inc (grau)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
subplot(223)
pcolor(yy,xx,ah);title('|T| (nT)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%
% Programa para comparar resultados de calculo no
% MATLAB e por progsFORTRAN
%
clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
load tt.dat -ascii
load tx.dat -ascii
load ty.dat -ascii
load tz.dat -ascii
load gz.dat -ascii
load gzx.dat -ascii
load gzy.dat -ascii
load gzz.dat -ascii
%
load agz.dat -ascii
load at.dat -ascii
load fdmr.dat -ascii
load fnic.dat -ascii
%
load pp.dat -ascii
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
np=length(pp(:,1));
[nx,ny]=size(tt);
%
%
caf=180/pi;
for ix=1:nx
    for iy=1:ny
        T=[tx(ix,iy)   ty(ix,iy)  tz(ix,iy)];
        G=[gzx(ix,iy) gzy(ix,iy) gzz(ix,iy)];
        aT=sqrt(dot(T,T));
        aG=sqrt(dot(G,G));
        aU=dot(T/aT,G/aG);
        Rmd(ix,iy)=0.05307*aT/aG;
        Rnc(ix,iy)=caf*asin(aU);
        AT(ix,iy)=aT;
        AG(ix,iy)=aG;
    end
end
%--------------------------------
figure
pcolor(yy,xx,AG);title('grad Gz (mGal/km)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')

figure
pcolor(yy,xx,agz);title('grad Gz (mGal/km) F O R T R A N')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')

%--------------------------------
figure
pcolor(yy,xx,AT);title('T (nT)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')

figure
pcolor(yy,xx,at);title('T (nT) F O R T R A N')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%--------------------------------
%
% RMD
figure
rmdV=pp(1,7)/pp(1,11);
ch=[' r=' num2str(rmdV)];
pcolor(yy,xx,Rmd);title(['RMD (mA.m2/kg) ' ch])
caxis([0 3])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')

figure
rmdV=pp(1,7)/pp(1,11);
ch=[' r=' num2str(rmdV)];
pcolor(yy,xx,fdmr);title(['RMD (mA.m2/kg) ' ch ' F O R T R A N'])
caxis([0 3])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%
% Inc
figure
incV=pp(1,8);
ch=[' I=' num2str(incV) ' D=' num2str(pp(1,11))];
pcolor(yy,xx,Rnc);title(['INC (grau) ' ch])
caxis([-90 90])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')

figure
pcolor(yy,xx,fnic);title(['INC (grau) ' ch ' F O R T R A N'])
caxis([-90 90])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')


open('10.fig');print -depsc -r300 10
open('11.fig');print -depsc -r300 11
open('12.fig');print -depsc -r300 12
open('13.fig');print -depsc -r300 13


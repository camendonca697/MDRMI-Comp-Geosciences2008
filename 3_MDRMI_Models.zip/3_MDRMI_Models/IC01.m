clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
load tt.dat -ascii
load tx.dat -ascii
load ty.dat -ascii
load tz.dat -ascii
load pp.dat -ascii
%
load agz.dat -ascii
load at.dat -ascii
load fdmr.dat -ascii
load fnic.dat -ascii


xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
np=length(pp(:,1));
[nx,ny]=size(tt);
%

%--------------------------------
figure
pcolor(yy,xx,tt);title('Tt (nT)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')

figure
pcolor(yy,xx,at);title('T (nT)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-');
%--------------------------------

figure
pcolor(yy,xx,tx);title('Tx (nT)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-');
%--------------------------------


figure
pcolor(yy,xx,ty);title('Ty (nT)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-');
%--------------------------------

figure
pcolor(yy,xx,tz);title('Tz (nT)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-');
%--------------------------------

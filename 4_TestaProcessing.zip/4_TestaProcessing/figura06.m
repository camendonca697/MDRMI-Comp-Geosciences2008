%
% DERIVADAS DA ANOMALIA GRAV
% Valores calculados (CALC) e obtidos por filtragem (FILT)
clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
% campos CALC
load gz.dat -ascii
load tt.dat -ascii
% Campos FILT
load fltat.dat -ascii
load fltagz.dat -ascii
load fltfdmr.dat -ascii
load fltfnic.dat -ascii
%
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
%
%
figure
pcolor(yy,xx,gz);title('gz (mGal)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%------------------------------------
figure
pcolor(yy,xx,fltagz);title('grad Gz (mGal/km) [FILT]')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%-------------------------------------
figure
pcolor(yy,xx,tt);title('Tt (nT)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%-------------------------------------
figure
pcolor(yy,xx,fltat);title('ModT (nT) [FILT]')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%-------------------------------------
%
% RMD
figure
rmdV=max(pp(:,7)./pp(:,11));
ch=[' r=' num2str(rmdV)];
pcolor(yy,xx,fltfdmr);
hold on
contour(yy,xx,fltfdmr,[0.999*rmdV 1.001*rmdV],'k')
hold off
title(['RMD (A.m2/kg) ' ch ' F I L T'])
caxis([0 round(1.5*rmdV)])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%
% Inc
figure
incV=pp(1,8);
ch=[' I=' num2str(incV) ' D=' num2str(pp(1,11))];
pcolor(yy,xx,fltfnic);title(['INC (grau) ' ch ' F I L T'])
hold on
contour(yy,xx,fltfnic,[0.999*incV 1.001*incV],'k')
hold off
caxis([-90 90])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
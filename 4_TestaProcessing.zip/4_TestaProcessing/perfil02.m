clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
% campos CALC
load gz.dat -ascii
load tt.dat -ascii
load agz.dat -ascii
load at.dat -ascii
load fdmr.dat -ascii
load fnic.dat -ascii
% Campos FILT
load fltagz.dat -ascii
load fltat.dat -ascii
load fltfdmr.dat -ascii
load fltfnic.dat -ascii
%
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
np=length(pp(:,1));
ic=64;
INC=hp(4);
%
%
dx=mean(diff(xx));
V=mdrmi(xx,1,gz(:,ic),tt(:,ic),INC,dx,0,0);
%
%------------------------------------
figure
subplot(211)
h=plot(xx,fnic(:,ic),'-b',xx,fltfnic(:,ic),'-k',xx,V(:,2),'-r');
legend('true','2D flt','1D flt')
%set(h,'markersize',3);
hold on
for i=1:np
    rd=pp(i,8);
    plot([xi xf],[rd rd],'-b')
end
hold off
ylabel('IM (grau)')


subplot(212)
h=plot(xx,fdmr(:,ic),'-b',xx,fltfdmr(:,ic),'-k',xx,V(:,1),'-r');
legend('true','2D flt','1D flt')
%set(h,'markersize',3);
hold on
for i=1:np
    rd=pp(i,7)/pp(i,11);
    plot([xi xf],[rd rd],'-b')
end
hold off
ylabel('RMD (mA.m2/kg)')
xlabel('Distancia (km)')



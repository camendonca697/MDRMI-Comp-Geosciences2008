%
% Campos Mag
% Valores calculados (CALC) e obtidos por filtragem (FILT)
clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
% campos CALC
load tt.dat -ascii
load tx.dat -ascii
load ty.dat -ascii
load tz.dat -ascii
load at.dat -ascii
% Campos FILT
load flttx.dat -ascii
load fltty.dat -ascii
load flttz.dat -ascii
load fltat.dat -ascii
%
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
%
%
figure
subplot(121)
pcolor(yy,xx,tt);title('Tt (nT)')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')

%------------------------------------
figure
subplot(121)
pcolor(yy,xx,tx);title('Tx (nT) [CALC]')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
w=caxis;
subplot(122)
pcolor(yy,xx,flttx);title('Tx (nT) [FILT]')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
caxis(w)
%-------------------------------------
figure
subplot(121)
pcolor(yy,xx,ty);title('Ty (nT) [CALC]')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
w=caxis;
subplot(122)
pcolor(yy,xx,fltty);title('Ty (nT) [FILT]')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
caxis(w)
%-------------------------------------
figure
subplot(121)
pcolor(yy,xx,tz);title('Tz (nT) [CALC]')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
w=caxis;
subplot(122)
pcolor(yy,xx,flttz);title('Tz (nT) [FILT]')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
caxis(w)
%-------------------------------------
figure
subplot(121)
pcolor(yy,xx,at);title('ModT (nT) [CALC]')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
w=caxis;
subplot(122)
pcolor(yy,xx,fltat);title('ModT (nT) [FILT]')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
caxis(w)
%-------------------------------------

figura04


figura07
figura08
figura08a
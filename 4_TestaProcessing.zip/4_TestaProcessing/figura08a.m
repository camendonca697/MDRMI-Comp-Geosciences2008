%
% DERIVADAS DA ANOMALIA GRAV
% Valores calculados (CALC) e obtidos por filtragem (FILT)
clear
% campos CALC
load at.dat -ascii
load agz.dat -ascii
% Campos FILT
load fltat.dat -ascii
load fltagz.dat -ascii
%
%
%------------------------------------
ic=floor(length(at(1,:))/2);
figure
h=plot(agz(:,ic)*14.993,at(:,ic),'-sk',fltagz(:,ic)*14.993,fltat(:,ic),'-sr');
set(h,'markersize',2)
legend('[Model evaluated]','[Filtered]')
xlabel('(mGal/km)*14.993')
ylabel('(nT)')
axis square
grid on


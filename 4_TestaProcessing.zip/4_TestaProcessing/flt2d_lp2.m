function fpb=flt2d_lp2(V,W,ch1,ch2)
% 
% Esta rotina permite a escolha da frequencia de 
% corte de um filtro tipo passa-baixa 
%
n=length(W);
n2=n/2;
Aw=abs(W);
mAw=max(Aw);
Av=abs(V);
mAv=max(Av);
rt=mAw/mAv;
Av=Av*rt;
fnd=1:n2;
figure;
h=semilogy(fnd,Aw(1:n2),'-ks',fnd,Av(1:n2),'-ro');
legend(ch1,ch2)
set(h,'markersize',3);
axis([1 n2 mAw*1e-11 1.5*mAw])
grid on
axis square
xlabel('Frequency  (1/km)')
ylabel(['Normalized Power Spectrum (factor =' num2str(mAw) ')'] )
[nc nau]=ginput(1);
nc=floor(nc);
fpb=ones(n,1);
fpb(nc+1:n-nc,1)=10^(-10)*ones(n-2*nc,1);
hold on
semilogy(fnd,mAw*fpb(1:n2),'-b');
hold off

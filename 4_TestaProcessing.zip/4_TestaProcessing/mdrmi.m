function V=mdrmi(x,ip,Gz,Tt,INC,dx,h,hhg)
% input
%    	 x = station coordinates (km)
%       ip = 1 apply low pass filtering
%       Gz = gravity anomaly (mGal)
%   	Tt = magnetic anomaly (nT)
%	   INC = apparent inclination of the inducing field (degree)
%        h = height of the magnetic data continuation (km)
%      hhg = height of the gravity data continuation (km)
%       
% output
%		MDR = magnetic-to-density ratio (mA.m2/kg)
%        MI = magnetization apparent inclination
%--------------------------------------------------
n=length(x);             % IMPORTANT: n must be power two
fc=0.01745329251994;
L=cos(INC*fc);
N=sin(INC*fc);
% a) magnetic filters
d=Tt;
Di=d(1);Df=d(n);m2=1.5*n;n2=2*n;n=4*n;
fnyq=1/(2*dx);
df=1/[(n-1)*dx];
f=[-fnyq:df:fnyq]';
ff=(0:df:(m2-1)*df)';
alf=log(0.0001)/[(m2-1)*df];
ff=exp(alf*ff);
dci=Di*flipud(ff);dcf=Df*ff;
dw=[dci; d; dcf];
k=2*pi*f;
K=abs(k);
fh=exp(K*h);			% MAG upward continuation
fx=i*k.*fh;				% x-derivative
fz=K.*fh;	 			% z-derivative
ad=i*L*k+N*K;
fX=fx./ad;				% x-component
fZ=fz./ad;			  	% z-component
DM=fft(dw,n);DM(1)=0;
%
% b) gravity filters
n=length(x);
d=Gz;
Di=d(1);Df=d(n);m2=1.5*n;n2=2*n;n=4*n;
dci=Di*flipud(ff);dcf=Df*ff;dw=[dci; d; dcf];
FH=exp(K*(h+hhg));	    % GRV upward continuation
FX=i*k.*fh;				% x-derivative
FZ=K.*fh;	 			% z-derivative
DG=fft(dw,n);DG(1)=0;
%
% c) Low pass filtering
if ip==1
    fpb=flt2d_lp2(DM,DG,'mag','grv');
    DM=DM.*fpb;
    DM=DM.*fpb;
end
%
% d) Filtering at all
F=[fX(n2+1:n); fX(1:n2)];a=real(ifft(F.*DM,n));Tx=a(m2+1:n-m2);
F=[fZ(n2+1:n); fZ(1:n2)];a=real(ifft(F.*DM,n));Tz=a(m2+1:n-m2);
F=[FX(n2+1:n); FX(1:n2)];a=real(ifft(F.*DG,n));gx=a(m2+1:n-m2);
F=[FZ(n2+1:n); FZ(1:n2)];a=real(ifft(F.*DG,n));gz=a(m2+1:n-m2);
%
% e) MDR and MI evaluation
TT=sqrt(Tx.*Tx+Tz.*Tz);
GG=sqrt(gx.*gx+gz.*gz);
MDR=0.066700*TT./GG;
MI=57.295779*asin([gx.*Tx+gz.*Tz]./[TT.*GG]);
V=[MDR MI];
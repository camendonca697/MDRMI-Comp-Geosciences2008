%
% DERIVADAS DA ANOMALIA GRAV
% Valores calculados (CALC) e obtidos por filtragem (FILT)
clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
% campos CALC
load fdmr.dat -ascii
load fnic.dat -ascii
% Campos FILT
load fltfdmr.dat -ascii
load fltfnic.dat -ascii
%
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
%
%
%------------------------------------
figure
subplot(121)
pcolor(yy,xx,fdmr);title('RMD (mA.m2/kg) [CALC]')
caxis([0 4]);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
;
subplot(122)
pcolor(yy,xx,fltfdmr);title('RMD (mA.m2/kg) [FILT]')
caxis([0 4]);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
%-------------------------------------
figure
subplot(121)
pcolor(yy,xx,fnic);title('RMD (mA.m2/kg) [CALC]')
caxis([-90 90]);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-');
subplot(122)
pcolor(yy,xx,fltfnic);title('RMD (mA.m2/kg) [FILT]')
caxis([-90 90]);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')

%
% DERIVADAS DA ANOMALIA GRAV
% Valores calculados (CALC) e obtidos por filtragem (FILT)
clear
% campos CALC
load at.dat -ascii
load agz.dat -ascii
% Campos FILT
load fltat.dat -ascii
load fltagz.dat -ascii
%
%
%------------------------------------
figure
h=plot(agz(:,:)*14.993,at(:,:),'sk');
set(h,'markersize',2)
xlabel('(mGal/km)*14.993')
ylabel('(nT)')
title('[Model evaluated]')
axis square
grid on
w=axis;
%
figure
h=plot(fltagz(:,:)*14.993,fltat(:,:),'sr');
set(h,'markersize',2)
xlabel('(mGal/km)*14.993')
ylabel('(nT)')
title('[Filtered]')
axis square
grid on
axis(w)

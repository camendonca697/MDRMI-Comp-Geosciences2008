open('1.fig');print -depsc -r300 1
open('2.fig');print -depsc -r300 2
open('3.fig');print -depsc -r300 3



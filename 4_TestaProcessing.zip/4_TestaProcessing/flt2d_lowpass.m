function fpb=flt2d_lowpass(V,W)
% 
% Esta rotina permite a escolha interativa da frequencia de 
% corte de um filtro tipo passa-baixa (passa-baixas, conforme os frescos)
%
n=length(W);
n2=n/2;
Aw=abs(W);
mAw=max(Aw);
Av=abs(V);
mAv=max(Av);
rt=mAw/mAv;
Av=Av*rt;
fnd=1:n2;
figure;
h=semilogy(fnd,Aw(1:n2),'-ks',fnd,Av(1:n2),'-ro');
set(h,'markersize',3);
axis([1 n2 mAw/10000 mAw])
[nc nau]=ginput(1);
nc=floor(nc);
fpb=ones(n,1);
fpb(nc+1:n-nc,1)=10^(-10)*ones(n-2*nc,1);

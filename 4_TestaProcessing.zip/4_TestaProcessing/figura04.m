%
% DERIVADAS DA ANOMALIA GRAV
% Valores calculados (CALC) e obtidos por filtragem (FILT)
clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
% campos CALC
load gz.dat -ascii
load gzx.dat -ascii
load gzy.dat -ascii
load gzz.dat -ascii
load agz.dat -ascii
% Campos FILT
load fltgzx.dat -ascii
load fltgzy.dat -ascii
load fltgzz.dat -ascii
load fltagz.dat -ascii
%
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
%
%
figure
subplot(121)
pcolor(yy,xx,gz);title('gz (mGal)')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
%------------------------------------
figure
subplot(121)
pcolor(yy,xx,gzx);title('dgz/dx (mGal/km) [CALC]')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
w=caxis;
subplot(122)
pcolor(yy,xx,fltgzx);title('dgz/dx (mGal/km) [FILT]')
caxis(w);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
%-------------------------------------
figure
subplot(121)
pcolor(yy,xx,gzy);title('dgz/dy (mGal/km) [CALC]')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
w=caxis;
subplot(122)
pcolor(yy,xx,fltgzy);title('dgz/dy (mGal/km) [FILT]')
caxis(w);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
%-------------------------------------
figure
subplot(121)
pcolor(yy,xx,gzz);title('dgz/dz (mGal/km) [CALC]')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
w=caxis;
subplot(122)
pcolor(yy,xx,fltgzz);title('dgz/dz (mGal/km) [FILT]')
caxis(w);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
%-------------------------------------
figure
subplot(121)
pcolor(yy,xx,agz);title('grad Gz (mGal/km) [CALC]')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
w=caxis;
subplot(122)
pcolor(yy,xx,fltagz);title('grad Gz (mGal/km) [FILT]')
caxis(w);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')

%-------------------------------------

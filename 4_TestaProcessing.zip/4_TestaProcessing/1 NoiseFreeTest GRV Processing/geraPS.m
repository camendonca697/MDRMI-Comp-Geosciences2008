open('1.fig');print -dpsc -r200 1
open('2.fig');print -dpsc -r100 2
open('3.fig');print -dpsc -r100 3
open('4.fig');print -dpsc -r100 4
open('5.fig');print -dpsc -r100 5


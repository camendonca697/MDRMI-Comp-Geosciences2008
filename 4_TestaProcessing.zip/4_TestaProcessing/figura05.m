%
%
clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
load tt.dat -ascii
load tx.dat -ascii
load ty.dat -ascii
load tz.dat -ascii
load gz.dat -ascii
load gzx.dat -ascii
load gzy.dat -ascii
load gzz.dat -ascii
%
load agz.dat -ascii
load at.dat -ascii
load fdmr.dat -ascii
load fnic.dat -ascii
%
load pp.dat -ascii
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
np=length(pp(:,1));
[nx,ny]=size(tt);
%
%
caf=180/pi;
for ix=1:nx
    for iy=1:ny
        T=[tx(ix,iy)   ty(ix,iy)  tz(ix,iy)];
        G=[gzx(ix,iy) gzy(ix,iy) gzz(ix,iy)];
        aT=sqrt(dot(T,T));
        aG=sqrt(dot(G,G));
        aU=dot(T/aT,G/aG);
        Rmd(ix,iy)=0.0667*aT/aG;
        Rnc(ix,iy)=caf*asin(aU);
        AT(ix,iy)=aT;
        AG(ix,iy)=aG;
    end
end
%--------------------------------
figure
pcolor(yy,xx,agz);title('grad Gz (mGal/km)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%--------------------------------
figure
pcolor(yy,xx,at);title('T (nT)')
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%--------------------------------
%
% RMD
figure
rmdV=pp(1,7)/pp(1,11);
ch=[' r=' num2str(rmdV)];
pcolor(yy,xx,fdmr);
hold on
contour(yy,xx,fdmr,[0.999*rmdV 1.001*rmdV],'k')
hold off
title(['RMD (A.m2/kg) ' ch ' F I L T'])
caxis([0 5])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')
%
% Inc
figure
incV=pp(1,8);
ch=[' I=' num2str(incV) ' D=' num2str(pp(1,11))];
pcolor(yy,xx,fnic);title(['INC (grau) ' ch ' F I L T'])
hold on
contour(yy,xx,fnic,[0.999*incV 1.001*incV],'k')
hold off
caxis([-90 90])
axis image;colorbar;shading flat
plotaprsm(pp,hp,'w-')


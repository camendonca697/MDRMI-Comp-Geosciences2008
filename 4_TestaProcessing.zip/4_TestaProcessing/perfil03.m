clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
% campos CALC
load gz.dat -ascii
load tt.dat -ascii
load agz.dat -ascii
load at.dat -ascii
load fdmr.dat -ascii
load fnic.dat -ascii
% Campos FILT
load fltagz.dat -ascii
load fltat.dat -ascii
load fltfdmr.dat -ascii
load fltfnic.dat -ascii
%
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
np=hp(1);
nx=hp(2);
ny=hp(3);
INC=hp(4);
%
%
dx=mean(diff(xx));
for iy=1:ny
    V=mdrmi(xx,0,gz(:,iy),tt(:,iy),INC,dx,0,0);
    mdr2d(:,iy)=V(:,1);
    mii2d(:,iy)=V(:,2);
end
%
%------------------------------------
figure
subplot(121)
pcolor(yy,xx,fdmr);title('RMD (mA.m2/kg) [Mod 3D]');
caxis([0 4]);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-');
subplot(122)
pcolor(yy,xx,mdr2d);title('RMD (mA.m2/kg) [FILT 2D]')
caxis([0 4]);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')

figure
subplot(121)
pcolor(yy,xx,fnic);title('IM (grau) [Mod 3D]')
caxis([-90 90]);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-');
subplot(122)
pcolor(yy,xx,mii2d);title('IM (grau) [FILT 2D]')
caxis([-90 90]);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')

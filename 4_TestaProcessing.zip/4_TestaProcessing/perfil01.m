clear
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
% campos CALC
load agz.dat -ascii
load at.dat -ascii
load fdmr.dat -ascii
load fnic.dat -ascii
% Campos FILT
load fltagz.dat -ascii
load fltat.dat -ascii
load fltfdmr.dat -ascii
load fltfnic.dat -ascii
%
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
np=length(pp(:,1));
%
%------------------------------------
figure
subplot(121)
pcolor(yy,xx,agz);title(' (mGal/km) [CALC]');
w=caxis;axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-');
subplot(122)
pcolor(yy,xx,fltagz);title(' (mGal/km) [FILT]')
caxis(w);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
ic=64;
figure
subplot(211)
h=plot(xx,agz(:,ic),'-k',xx,fltagz(:,ic),'sk');set(h,'markersize',3);
ylabel('Grad gz (mGal/km)')
xlabel('Distancia (km)')
%
%------------------------------------
%
%------------------------------------
figure
subplot(121)
pcolor(yy,xx,at);title(' (nT/km) [CALC]');
w=caxis;axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-');
subplot(122)
pcolor(yy,xx,fltat);title(' (nT/km) [FILT]')
caxis(w);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')
ic=64;
figure
subplot(211)
h=plot(xx,at(:,ic),'-k',xx,fltat(:,ic),'sk');set(h,'markersize',3);
ylabel('Mod Tt (nT/km)')
xlabel('Distancia (km)')
%
%------------------------------------
figure
subplot(121)
pcolor(yy,xx,fdmr);title('RMD (mA.m2/kg) [CALC]');
caxis([0 4]);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-');
subplot(122)
pcolor(yy,xx,fltfdmr);title('RMD (mA.m2/kg) [FILT]')
caxis([0 4]);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')

ic=64;
figure
subplot(211)
h=plot(xx,fnic(:,ic),'-r',xx,fltfnic(:,ic),'-sk');set(h,'markersize',3);
hold on
for i=1:np
    rd=pp(i,8);
    plot([xi xf],[rd rd],'--r')
end
hold off
ylabel('IM (grau)')
xlabel('Distancia (km)')

%-------------------------------------
figure
subplot(121)
pcolor(yy,xx,fnic);title('MI (degree) [CALC]')
caxis([-90 90]);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-');
subplot(122)
pcolor(yy,xx,fltfnic);title('MI (degree) [FILT]')
caxis([-90 90]);axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w-')


figure
subplot(211)
h=plot(xx,fdmr(:,ic),'-r',xx,fltfdmr(:,ic),'-sk');
set(h,'markersize',3);
hold on
for i=1:np
    rd=pp(i,7)/pp(i,11);
    plot([xi xf],[rd rd],'--r')
end
ylabel('MI (degree)')
hold off




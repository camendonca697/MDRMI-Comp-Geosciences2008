function v=plotaprsm(pp,hp,ch)
np=hp(1);
hold on
for i=1:np
    ag=-pp(i,10)*pi/180;
    R=[cos(ag) sin(ag);-sin(ag) cos(ag)];
    p0(1:2,1)=[pp(i,1) pp(i,2)]';
    p1(1:2,1)=[pp(i,1)-pp(i,3)/2 pp(i,2)-pp(i,4)/2]';
    p2(1:2,1)=[pp(i,1)+pp(i,3)/2 pp(i,2)-pp(i,4)/2]';
    p3(1:2,1)=[pp(i,1)+pp(i,3)/2 pp(i,2)+pp(i,4)/2]';
    p4(1:2,1)=[pp(i,1)-pp(i,3)/2 pp(i,2)+pp(i,4)/2]';
    p1=p0+R*[p1-p0];
    p2=p0+R*[p2-p0];
    p3=p0+R*[p3-p0];
    p4=p0+R*[p4-p0];
    x=[p1(1) p2(1) p3(1) p4(1) p1(1)]';
    y=[p1(2) p2(2) p3(2) p4(2) p1(2)]';
    plot(y,x,ch)
end
hold off

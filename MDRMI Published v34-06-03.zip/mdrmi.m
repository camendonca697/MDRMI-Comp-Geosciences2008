clear
%
% model evaluated fields
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
load tt.dat -ascii
load tx.dat -ascii
load ty.dat -ascii
load tz.dat -ascii
load gz.dat -ascii
load gzx.dat -ascii
load gzy.dat -ascii
load gzz.dat -ascii
%
%filtered fields
load fltat.dat -ascii
load fltagz.dat -ascii
load fltfdmr.dat -ascii
load fltfnic.dat -ascii
%
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
np=length(pp(:,1));
[nx,ny]=size(tt);
%
%
caf=180/pi;
for ix=1:nx
    for iy=1:ny
        T=[tx(ix,iy)   ty(ix,iy)  tz(ix,iy)];
        G=[gzx(ix,iy) gzy(ix,iy) gzz(ix,iy)];
        aT=sqrt(dot(T,T));
        aG=sqrt(dot(G,G));
        aU=dot(T/aT,G/aG);
        Rmd(ix,iy)=0.05307*aT/aG;
        Rnc(ix,iy)=caf*asin(aU);
        AT(ix,iy)=aT;
        AG(ix,iy)=aG;
    end
end

load gz.dat -ascii
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
np=length(pp(:,1));
%
%-------------------------------Grav&Mag anomalies
nc=15;
ji=32;jf=nx-32;
figure
subplot(121)
vi=0;vf=3;vd=(vf-vi)/(nc-1);vc=vi:vd:vf;
contourf(yy(ji:jf),xx(ji:jf),gz(ji:jf,ji:jf),vc);
title('gz (mGal)')
caxis([vi vf]);axis image;colorbar('horizontal');axis off
plotaprsm(pp,hp,'w')
subplot(122)
vi=-100;vf=40;vd=(vf-vi)/(nc-1);vc=vi:vd:vf;
contourf(yy(ji:jf),xx(ji:jf),tt(ji:jf,ji:jf),vc);
title('Tt (nT)')
caxis([vi vf]);axis image;colorbar('horizontal');axis off
plotaprsm(pp,hp,'w')
%-------------------------------- Intensity Fields
figure
subplot(121)
vi=0;vf=2.0;vd=(vf-vi)/(nc-1);vc=vi:vd:vf;
contourf(yy(ji:jf),xx(ji:jf),AG(ji:jf,ji:jf),vc);
title('(mGal/km)')
caxis([vi vf]);axis image;colorbar('horizontal');axis off
plotaprsm(pp,hp,'w-')
subplot(122)
vi=0;vf=2.0;vd=(vf-vi)/(nc-1);vc=vi:vd:vf;
contourf(yy(ji:jf),xx(ji:jf),fltagz(ji:jf,ji:jf),vc);
title('Filtered (mGal/km)')
caxis([vi vf]);axis image;colorbar('horizontal');axis off
plotaprsm(pp,hp,'w-')

figure
subplot(121)
vi=0;vf=100;vd=(vf-vi)/(nc-1);vc=vi:vd:vf;
contourf(yy(ji:jf),xx(ji:jf),AT(ji:jf,ji:jf),vc);
title('T (nT)')
caxis([vi vf]);axis image;colorbar('horizontal');axis off
plotaprsm(pp,hp,'w-')

subplot(122)
vi=0;vf=100;vd=(vf-vi)/(nc-1);vc=vi:vd:vf;
contourf(yy(ji:jf),xx(ji:jf),fltat(ji:jf,ji:jf),vc);
title('Filtered T (nT)')
caxis([vi vf]);axis image;colorbar('horizontal');axis off
plotaprsm(pp,hp,'w-')

%--------------------------------MDR-MI
figure
subplot(121)
vi=0;vf=5;vd=(vf-vi)/(nc-1);vc=vi:vd:vf;
contourf(yy(ji:jf),xx(ji:jf),Rmd(ji:jf,ji:jf),vc);
title('MDR (mA.m2/kg) ')
caxis([vi vf]);axis image;colorbar('horizontal');axis off
plotaprsm(pp,hp,'w-')
subplot(122)
vi=0;vf=5;vd=(vf-vi)/(nc-1);vc=vi:vd:vf;
contourf(yy(ji:jf),xx(ji:jf),fltfdmr(ji:jf,ji:jf),vc);
title('Filtered MDR (mA.m2/kg) ')
caxis([vi vf]);axis image;colorbar('horizontal');axis off
plotaprsm(pp,hp,'w-')

figure
subplot(121)
vi=-90;vf=90;vd=(vf-vi)/(nc-1);vc=vi:vd:vf;
contourf(yy(ji:jf),xx(ji:jf),Rnc(ji:jf,ji:jf),vc);
title('MI (degree) ')
caxis([vi vf]);axis image;colorbar('horizontal');axis off
plotaprsm(pp,hp,'w-')

subplot(122)
vi=-90;vf=90;vd=(vf-vi)/(nc-1);vc=vi:vd:vf;
contourf(yy(ji:jf),xx(ji:jf),fltfnic(ji:jf,ji:jf),vc);
title('Filtered MI (degree) ')
caxis([vi vf]);axis image;colorbar('horizontal');axis off
plotaprsm(pp,hp,'w-')




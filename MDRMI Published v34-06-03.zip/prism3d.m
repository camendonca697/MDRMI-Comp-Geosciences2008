clear
% Input
% position and model parameter
load xx.dat -ascii
load yy.dat -ascii
load pp.dat -ascii
load hp.dat -ascii
% fields
load tt.dat -ascii
load gz.dat -ascii
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
np=length(pp(:,1));
%
% graphics
figure
subplot(121)
pcolor(yy,xx,gz);title('gz (mGal)')
axis image;colorbar('horizontal');shading flat
plotaprsm(pp,hp,'w')
w=caxis;
subplot(122)
pcolor(yy,xx,tt);title('Tt (nT)')
axis image;colorbar('horizontal');
shading flat;
plotaprsm(pp,hp,'w')


%
%
clear
load xx.dat -ascii
load yy.dat -ascii
%
load fltfdmr.dat -ascii
load fltfnic.dat -ascii
%
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
nx=length(xx);
ny=length(yy);
%
%-------------------- RMD
nc=20;
figure
ci=min(min(fltfdmr));
cf=max(max(fltfdmr));
cc=rec(ci,cf,nc);
contourf(yy,xx,fltfdmr,cc);
title('RMD (A.m2/kg)')
caxis([ci cf])
axis image;colorbar;
%
%------------------- INC
ci=min(min(fltfnic));
cf=max(max(fltfnic));
dc=(cf-ci)/nc;
cc=ci:dc:cf;
figure
contourf(yy,xx,fltfnic,cc);
title('INC (grau)')
caxis([ci cf])
axis image;colorbar;



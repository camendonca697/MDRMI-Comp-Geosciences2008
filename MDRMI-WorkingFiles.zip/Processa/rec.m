function z=rec(ri,rf,n)
if ri<=0
disp('ri deve ser positivo');
return 
end 
xi=log(ri);
xf=log(rf);
dx=(xf-xi)/(n-1);
r=xi:dx:xf;
z=exp(r);

%
%
clear
load xx.dat -ascii
load yy.dat -ascii

load gz.dat -ascii
load tt.dat -ascii

load flttx.dat -ascii
load fltty.dat -ascii
load flttz.dat -ascii
load fltat.dat -ascii

load fltgzx.dat -ascii
load fltgzy.dat -ascii
load fltgzz.dat -ascii
load fltagz.dat -ascii

load fltfdmr.dat -ascii
load fltfnic.dat -ascii
%
xi=min(xx);xf=max(xx);
yi=min(yy);yf=max(yy);
[nx,ny]=size(tt);
%
%

%--------------------------------
figure
pcolor(yy,xx,gz);title('Gz (mGal)')
axis image;colorbar;shading flat

%--------------------------------
figure
pcolor(yy,xx,tt);title('Tt (nT)')
axis image;colorbar;shading flat

%--------------------------------
figure
pcolor(yy,xx,fltagz);title('grad Gz (mGal/km)')
axis image;colorbar;shading flat

%--------------------------------
figure
pcolor(yy,xx,fltat);title('T (nT)')
axis image;colorbar;shading flat

%--------------------------------
%
% RMD
figure
pcolor(yy,xx,fltfdmr);
title(['RMD (A.m2/kg) ' ' F I L T'])
caxis([0 5])
axis image;colorbar;shading flat

%
% Inc
figure
pcolor(yy,xx,fltfnic);title(['INC (grau) ' ' F I L T'])
caxis([-90 90])
axis image;colorbar;shading flat


